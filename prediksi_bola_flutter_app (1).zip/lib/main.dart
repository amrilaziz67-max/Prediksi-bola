import 'package:flutter/material.dart';
void main()=>runApp(MyApp());
class MyApp extends StatelessWidget{
  Widget build(BuildContext c){return MaterialApp(home:Scaffold(body:Center(child:Text('Prediksi Bola AI'))));}}
